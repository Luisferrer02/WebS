const express = require("express")
const router = express.Router();
const multer = require("multer");
const {uploadMiddleware, uploadMiddlewareMemory} = require("../utils/handleStorage")
const {createItem} = require("../controlers/storage")
const {getItems} = require("../controlers/tracks");
const {updateImage} = require("../controlers/storage");

//router.post("/", uploadMiddleware.single("image"), createItem);
router.get("/", getItems);

//router.patch("/", authMiddleware, uploadMiddleware.single("image"), updateImage)
router.post("/", uploadMiddlewareMemory.single("image"), updateImage)

module.exports = router;